from django.shortcuts import render, redirect
from django.http import HttpResponse
import requests
from django.contrib.auth import login as auth_login
from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm
from django import forms
from wifi import Cell, Scheme

from .models import Greeting

# Create your views here.
def index(request):
    # return HttpResponse('Hello from Python!')
    return render(request, 'index.html')

def login(request): 
	return render(request, 'login.html')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            if user is not None:
            	auth_login(request, user)
            	return render(request, 'index.html')
    else:
    	# options = Cell.all('wlan0')
        form = UserCreationForm()
    # return render(request, 'signup.html', {'form': form}, {'options': options})
    return render(request, 'signup.html', {'form': form})

def profile(request): 
	return render(request, 'index.html')


def db(request):

    greeting = Greeting()
    greeting.save()

    greetings = Greeting.objects.all()

    return render(request, 'db.html', {'greetings': greetings})

